package selenium_LMSProject;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Read_and_Verify_TitleofthefirstInfoBox {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		driver.get("https://alchemy.hguy.co/lms");
		//getting title of the first info box on the LMS Web page
		WebElement info = driver.findElement(By.xpath("//h3[contains(text(),'Actionable Training ')]"));
		String infoboxtitle = info.getText();
		System.out.println("Title of the first info box on LMS web page: " + infoboxtitle);
		String expectedtitle = "Actionable Training";
		//verifying title of the first info box on LMS Page
		Assert.assertEquals(infoboxtitle, expectedtitle);
		System.out.println("Title of the first info box matches !!!");
		driver.quit();
	}

}
