package selenium_LMSProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class NavigatetoContactuspage_and_SubmitForm {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		driver.get("https://alchemy.hguy.co/lms");
		//Navigate to contact page
		driver.findElement(By.linkText("Contact")).click();
		//Fill the form and submit
		driver.findElement(By.xpath("//input[@id='wpforms-8-field_0']")).sendKeys("Usha Rani");
		driver.findElement(By.xpath("//input[@id='wpforms-8-field_1']")).sendKeys("usharani@gmail.com");
		driver.findElement(By.xpath("//input[@id='wpforms-8-field_3']")).sendKeys("Regarding Assessment");
		driver.findElement(By.xpath("//textarea[@id='wpforms-8-field_2']")).
		sendKeys("Kindly let me know the Assessment Pattern and other details");
		driver.findElement(By.xpath("//button[@id='wpforms-submit-8']")).click();
		//getting the message on the page post form submission
		WebElement postsubmitmsg = driver.findElement(By.xpath("//div[@id = 'wpforms-confirmation-8']/p"));
		String msg = postsubmitmsg.getText();
		System.out.println("We got your message request. " + msg);
		driver.quit();
	}
}
