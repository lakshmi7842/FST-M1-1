package selenium_LMSProject;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Countnumofcourses_In_AllCoursespage {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		driver.get("https://alchemy.hguy.co/lms");
		//Navigating to All Courses page
		driver.findElement(By.linkText("All Courses")).click();
		//Storing all Courses in to List and getting no: of courses
		List<WebElement> coursecnt = driver.findElements(By.xpath("//div[@id='ld_course_list']/div/div/div/article/div[2]/h3"));
		System.out.println("The Number of Courses are "+ coursecnt.size());
		//Getting name of each course
		List<WebElement> courses = driver.findElements(By.xpath("//div[@id='ld_course_list']/div/div/div/article/div[2]/h3"));
		for(WebElement course: courses) {
			System.out.println(course.getText());
		}
		driver.quit();
	}

}