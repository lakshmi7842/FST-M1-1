package selenium_LMSProject;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class NaviagtetoMyAccountPage_and_VerifyPagetitle {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		driver.get("https://alchemy.hguy.co/lms");
		//Navigating to My Account page
		driver.findElement(By.partialLinkText("Account")).click();
		//Verifying if user is on correct page
		Assert.assertEquals(driver.getTitle(), "My Account � Alchemy LMS");
		System.out.println("Page Title: " +driver.getTitle());
		System.out.println("Welcome to Your Account. You are naviagted to correct page !!!");
		driver.quit();
	}

}
