package selenium_LMSProject;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Read_and_match_WebsiteTitle {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		driver.get("https://alchemy.hguy.co/lms");
		//getting title of the website
		String actualTitle = driver.getTitle();
		System.out.println("Website Title: " + actualTitle);
		String expectedTitle = "Alchemy LMS � An LMS Application";
		//Checking if Title of the website matches
		Assert.assertEquals(actualTitle, expectedTitle);
		System.out.println("Title Matched");
		driver.quit();
	}

}
