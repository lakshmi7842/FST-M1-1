package selenium_LMSProject;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Read_and_Verify_TitleofSecondMostPopularCourse {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		driver.get("https://alchemy.hguy.co/lms");
		//getting title of the second most popular course on the LMS Web page
		WebElement course = driver.findElement(By.xpath("//h3[contains(text(),'Email Marketing Strategies')]"));
		String coursetitle = course.getText();
		System.out.println("Title of the Second Most Popular Course on LMS web page: " + coursetitle);
		String expectedtitle = "Email Marketing Strategies";
		//checking if Second most popular course matches expected title
		Assert.assertEquals(coursetitle, expectedtitle);
		System.out.println("Title of the Seond most popular course matches !!!");
		driver.quit();
	}
	
}
