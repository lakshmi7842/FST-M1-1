package selenium_LMSProject;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class LogintoLMSWebsite {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		driver.get("https://alchemy.hguy.co/lms");
		//Navigating to My Account page
		driver.findElement(By.partialLinkText("Account")).click();
		System.out.println("Page Title: " +driver.getTitle());
		//Verifying Page Title
		Assert.assertEquals(driver.getTitle(), "My Account � Alchemy LMS");
		System.out.println("Welcome to Your Account !!!");
		//Login in to Account
		driver.findElement(By.linkText("Login")).click();
		driver.findElement(By.name("log")).sendKeys("root");
		driver.findElement(By.name("pwd")).sendKeys("pa$$w0rd");
		driver.findElement(By.name("wp-submit")).click();
		String actualURL = driver.getCurrentUrl();
		String expectedURL = "https://alchemy.hguy.co/lms/my-account/";
		//verifying if user is logged in
		if(actualURL.equals(expectedURL)) {
			System.out.println("User successfully logged in");
			driver.quit();
		}
		else {
			System.out.println("User unable to login. Check credentails");
			}
		
	}

}
