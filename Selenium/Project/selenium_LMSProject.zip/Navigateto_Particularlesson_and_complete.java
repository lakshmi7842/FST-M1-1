package selenium_LMSProject;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Navigateto_Particularlesson_and_complete {
	public static void main(String[] args) throws InterruptedException{
		WebDriver driver = new FirefoxDriver();
		driver.get("https://alchemy.hguy.co/lms");
		//log in to Website
		driver.findElement(By.partialLinkText("Account")).click();
		driver.findElement(By.linkText("Login")).click();
		driver.findElement(By.name("log")).sendKeys("root");
		driver.findElement(By.name("pwd")).sendKeys("pa$$w0rd");
		driver.findElement(By.name("wp-submit")).click();
		//Navigate to All Courses page and clicking on particular course
		driver.findElement(By.linkText("All Courses")).click();
		driver.findElement(By.cssSelector("#post-24042 > div:nth-child(3) > p:nth-child(3) > a")).click();
		Thread.sleep(60);
		System.out.println("Course Title: " +driver.getTitle());
		//Clicking on particular lesson inside course
		driver.findElement(By.xpath("//div[contains(text(),'Analyze Content & Develop Writing Strategies')]")).click();
		Thread.sleep(120);
		String lessontitle = driver.getTitle();
		//Verifying lesson title
		Assert.assertEquals(lessontitle, "Analyze Content & Develop Writing Strategies � Alchemy LMS");
		System.out.println("Lesson Title: " + lessontitle);
		driver.quit();
	}
}
