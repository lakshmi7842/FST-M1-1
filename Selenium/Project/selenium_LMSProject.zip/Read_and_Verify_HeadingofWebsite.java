package selenium_LMSProject;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Read_and_Verify_HeadingofWebsite {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		driver.get("https://alchemy.hguy.co/lms");
		//Getting heading of the web page
		WebElement heading = driver.findElement(By.xpath("//h1[contains(@class,'uagb-ifb-title')]"));
		String webheading = heading.getText();
		System.out.println("Heading of the LMS Website: " + webheading);
		String expectedheading = "Learn from Industry Experts";
		//checking if heading of web page matches "Learn from Industry Experts"
		Assert.assertEquals(webheading,expectedheading);
		System.out.println("Heading matches !!!");
		driver.quit();
	}

}
