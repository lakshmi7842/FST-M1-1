//Login and retrieve the emergency contacts for the user package selenium_HRMProject;
package selenium_HRMProject;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Activity9 {
	public static void main(String[] args)throws InterruptedException{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.findElement(By.name("txtUsername")).sendKeys("orange");
		driver.findElement(By.name("txtPassword")).sendKeys("orangepassword123");
		driver.findElement(By.className("button")).click();
		//Navigating to My Info page
		driver.findElement(By.xpath("//a[@id = 'menu_pim_viewMyDetails']/b")).click();
		//Navigating to Emergency Contacts
		driver.findElement(By.cssSelector("#sidenav > li:nth-child(3) > a:nth-child(1)")).click();
		//Storing all the Emergency contacts data in to List
		List<WebElement> allRows = driver.findElements(By.xpath("//table[@id ='emgcontact_list']//tr")); 
		for (WebElement row : allRows) { 
			List<WebElement> cells = row.findElements(By.tagName("td")); 
			// Print the contents of each cell
		    for (WebElement cell : cells) {         
		    	System.out.print(cell.getText()+ "|");
		    }
		    System.out.println();
		}
		driver.quit();
	}
}
