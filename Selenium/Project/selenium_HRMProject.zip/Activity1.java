//Read the title of the website and verify the text
package selenium_HRMProject;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Activity1 {
			public static void main(String[] args) {
				WebDriver driver = new FirefoxDriver();
				driver.get("http://alchemy.hguy.co/orangehrm");
				String actualTitle = driver.getTitle();
				System.out.println("Website Title: " + actualTitle);
				String expectedTitle = "OrangeHRM";
				//Checking if Title of the website matches "OrangeHRM"
				Assert.assertEquals(actualTitle, expectedTitle);
				System.out.println("Title Matched");
				driver.quit();
			}
		
}
