//Add employee qualifications
package selenium_HRMProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Activity7 {
	public static void main(String[] args)throws InterruptedException{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.findElement(By.name("txtUsername")).sendKeys("orange");
		driver.findElement(By.name("txtPassword")).sendKeys("orangepassword123");
		driver.findElement(By.className("button")).click();
		//Navigating to My Info page
		driver.findElement(By.xpath("//a[@id = 'menu_pim_viewMyDetails']/b")).click();
		//Navigating to Qualifications page
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/ul/li[9]/a")).click();
		//adding employee work experience
		driver.findElement(By.xpath("//input[@id = 'addWorkExperience']")).click();
		WebElement Company = driver.findElement(By.xpath("//input[@id = 'experience_employer']"));
		Company.sendKeys("Deloitte");
		String companyname = Company.getAttribute("value");
		WebElement Jobtitle = driver.findElement(By.xpath("//input[@id = 'experience_jobtitle']"));
		Jobtitle.sendKeys("Test Manager");
		String Empjobtitle = Jobtitle.getAttribute("value");
		driver.findElement(By.xpath("//input[@id = 'btnWorkExpSave']")).click();
		System.out.println("Employee Qualifications added successfully");
		System.out.println("Employee Working in " + companyname + " as " + Empjobtitle);
		driver.quit();
	}

}
