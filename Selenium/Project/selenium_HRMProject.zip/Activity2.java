// Print the URL of the header image to the console
package selenium_HRMProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebElement;
public class Activity2 {

	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		driver.get("http://alchemy.hguy.co/orangehrm");
		System.out.println("Website Title: " + driver.getTitle());
		WebElement URL = driver.findElement(By.xpath("//div[@id = 'divLogo']/img"));
		//get source/URL of the header image
		System.out.println("Src of the header image: " + URL.getAttribute("src"));
		driver.quit();
	}

}
