//Open the site and login with the credentials provided
package selenium_HRMProject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Activity3 {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
				driver.get("http://alchemy.hguy.co/orangehrm");
				//Login in to Website with user name and password
				driver.findElement(By.name("txtUsername")).sendKeys("orange");
				driver.findElement(By.name("txtPassword")).sendKeys("orangepassword123");
				driver.findElement(By.className("button")).click();
				String expectedURL = "http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/dashboard";
				//checking if page navigated to home page after login
				Assert.assertEquals(expectedURL, driver.getCurrentUrl());
				System.out.println("Navigated to Home page of OrangeHRM Website");
				driver.quit();
	}

}
