package selenium_HRMProject;
import java.time.Duration;
import java.util.List;
//import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
public class Activity8 {
	
	public static void main(String[] args) throws InterruptedException{
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.findElement(By.name("txtUsername")).sendKeys("orange");
		driver.findElement(By.name("txtPassword")).sendKeys("orangepassword123");
		driver.findElement(By.className("button")).click();
		Thread.sleep(600);
		//navigate to Apply Leave page
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/ul/li[8]/a/b")).isEnabled();
		driver.findElement(By.xpath("//div[@id='dashboard-quick-launch-panel-container']/div/table/tbody/tr/td[4]/div/a")).click();
		//Selecting Leave Type from drop down
		//Thread.sleep(600);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id = 'applyleave_txtLeaveType']")));
		Select lvtype = new Select(driver.findElement(By.xpath("//select[@id = 'applyleave_txtLeaveType']")));
		lvtype.selectByVisibleText("DayOff");
		//FromDate
		driver.findElement(By.id("applyleave_txtFromDate")).click();
		
		//sept23
		/*Thread.sleep(20);
		while(!driver.findElement(By.cssSelector("[class='ui-datepicker-title'][class='ui-datepicker-month']")).getText().contains("Oct")) {
			driver.findElement(By.cssSelector("[class='ui-datepicker-month']")).click();
		}*/
		
		//Grab the common element //put into the list and then iterate.
		List<WebElement> dates = driver.findElements(By.className("ui-state-default"));
		int count=driver.findElements(By.className("ui-state-default")).size();
		
		for(int i=0;i<count;i++) {
			String text=driver.findElements(By.className("ui-state-default")).get(i).getText();
			if(text.equalsIgnoreCase("23")) {
				driver.findElements(By.className("ui-state-default")).get(i).click();
				String fromText=driver.findElements(By.className("ui-state-default")).get(i).getText();
				System.out.println("From Date: " +fromText);
				break;
			}
		
		}
		
		//ToDate
		driver.findElement(By.id("applyleave_txtToDate")).click();
		//sept26
		List<WebElement> toDates = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']/tbody/tr/td"));
		int toCount=driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']/tbody/tr/td")).size();
		
		for(int j=0;j<count;j++) {
			String toText=driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']/tbody/tr/td")).get(j).getText();
			if(toText.equalsIgnoreCase("26")) {
				driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']/tbody/tr/td")).get(j).click();
				String todateText=driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']/tbody/tr/td")).get(j).getText();
				System.out.println("From Date: " +todateText);
				break;
			}			
		}
		
		driver.findElement(By.id("applyBtn")).click();
		driver.findElement(By.id("menu_leave_viewMyLeaveList")).click();
		Thread.sleep(20);
		driver.findElement(By.id("calFromDate")).clear();
		driver.findElement(By.id("calFromDate")).sendKeys("2022-08-23");
		driver.findElement(By.id("calToDate")).clear();
		driver.findElement(By.id("calToDate")).sendKeys("2022-08-26");
		driver.findElement(By.id("btnSearch")).click();
		Thread.sleep(10);
		List<WebElement> status = driver.findElements(By.xpath("//table[@id='resultTable']/tbody/tr/td[6]/a"));
		for(WebElement state:status) {
			System.out.println(state.getText());
		}
		
		
	}
}