//Add an employee and their details to the site
package selenium_HRMProject;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
public class Activity4 {
	public static void main(String[] args)throws InterruptedException{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.findElement(By.name("txtUsername")).sendKeys("orange");
		driver.findElement(By.name("txtPassword")).sendKeys("orangepassword123");
		driver.findElement(By.className("button")).click();
		//navigating to PIM Page and adding employee
		driver.findElement(By.xpath("//a[@id = 'menu_pim_viewPimModule']/b")).click();
		Thread.sleep(120);
		driver.findElement(By.xpath("//input[@id = 'btnAdd']")).click();
		driver.findElement(By.xpath("//input[@id = 'firstName']")).sendKeys("Naomi");
		driver.findElement(By.xpath("//input[@id = 'lastName']")).sendKeys("Locke");
		driver.findElement(By.xpath("//input[@id = 'btnSave']")).click();
		//Navigating to Employee List page for searching employee who was added above
		driver.findElement(By.xpath("//a[@id = 'menu_pim_viewEmployeeList']")).click();
		Thread.sleep(120);
		driver.findElement(By.xpath("//input[@id = 'empsearch_employee_name_empName']")).sendKeys("Naomi Locke",Keys.TAB);
		WebElement Search = driver.findElement(By.xpath("//input[@id = 'searchBtn']"));
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(Search));
		Search.click();
		//checking if the employee added is displaying or not
		driver.findElement(By.xpath("//*[@id=\"resultTable\"]/tbody/tr/td[3]/a")).isDisplayed();
		System.out.println("Employee Added successfully");
		driver.quit();
	}

}
