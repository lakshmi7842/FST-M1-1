//Edit a user�s information
package selenium_HRMProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
public class Activity5 {
	public static void main(String[] args)throws InterruptedException{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.findElement(By.name("txtUsername")).sendKeys("orange");
		driver.findElement(By.name("txtPassword")).sendKeys("orangepassword123");
		driver.findElement(By.className("button")).click();
		//navigating to My Info page
		driver.findElement(By.xpath("//a[@id = 'menu_pim_viewMyDetails']/b")).click();
		Thread.sleep(120);
		//editing the employee details
		driver.findElement(By.xpath("//input[@value = 'Edit']")).click();
		WebElement fnameedit = driver.findElement(By.xpath("//input[@id = 'personal_txtEmpFirstName']"));
		//clearing the existing data in the fname, lname fields and entering new names
		fnameedit.clear();
		fnameedit.sendKeys("editedFname");
		WebElement lnameedit = driver.findElement(By.xpath("//input[@id = 'personal_txtEmpLastName']"));
		lnameedit.clear();
		lnameedit.sendKeys("editedlastname");
		driver.findElement(By.xpath("//ul[contains(@class,'radio_list')]/li[1]")).click();
		//selecting value form Country drop down
		Select country = new Select(driver.findElement(By.xpath("//select[@id = 'personal_cmbNation']")));
		country.selectByVisibleText("Bulgarian");
		driver.findElement(By.xpath("//input[@value = 'Save']")).click();
		System.out.println("Edited Employee Info successfully");
		driver.quit();
	}

}
