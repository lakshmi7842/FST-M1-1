package selenium_HRMProject;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
public class Activity6 {
	public static void main(String[] args)throws InterruptedException{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.findElement(By.name("txtUsername")).sendKeys("orange");
		driver.findElement(By.name("txtPassword")).sendKeys("orangepassword123");
		driver.findElement(By.className("button")).click();
		//Checking if Directory menu is visible
		Thread.sleep(40);
		WebElement Directory = driver.findElement(By.xpath("/html/body/div[1]/div[2]/ul/li[9]/a/b"));
		Boolean result = Directory.isDisplayed();
		System.out.println("Is Directory Menu Item Visible: " + result);
		//checking if Directory menu is clickable
		WebDriverWait wt = new WebDriverWait(driver,Duration.ofSeconds(300));
		//wt.until(ExpectedConditions.elementToBeClickable(Directory));
		if(wt.until(ExpectedConditions.elementToBeClickable(Directory)) != null){
			Assert.assertEquals(Directory.getText(), "Directory");
			System.out.println("Clickable");
			
		}
		else {
			System.out.println("Not Clickable");
		}
		Thread.sleep(600);
		Directory.click();	
		//Thread.sleep(600);
		//checking if heading of the page is "Search Directory" after navigating to Directory menu
		WebElement direheading = driver.findElement(By.xpath("//div[@class='head']/h1"));
		String heading = direheading.getText();
		System.out.println("heading of the page after navigating to Directory menu: " + heading);
		String expectedheading = "Search Directory";
		Assert.assertEquals(heading, expectedheading);
		System.out.println("Heading of the page matches 'Seach Directory'");
		driver.quit();
				
		
	}
}